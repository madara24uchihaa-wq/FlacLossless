#!/usr/bin/env bash
# build.sh for Render deployment

set -o errexit

pip install -r requirements.txt
